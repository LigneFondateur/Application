﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGestionEquipe
{
    public class GestionAdhesion
    {
        private ConnexionBdd connexion;

        public GestionAdhesion(ConnexionBdd connexion)
        {
            this.connexion = connexion;
        }

        public int GetCount()
        {
            // Requête SQL pour compter le nombre de demandes
            string query = "SELECT COUNT(*) FROM Demande_Adhesion";

            // Exécution de la requête pour obtenir le nombre de demandes
            object result = connexion.ExecuterScalaire(query);

            // Conversion du résultat en entier
            int count = 0;
            if (result != null && int.TryParse(result.ToString(), out count))
            {
                return count;
            }
            else
            {
                // Gérer le cas où la requête ne renvoie pas un nombre valide
                throw new Exception("Impossible de récupérer le nombre de demandes.");
            }
        }
    }
}
