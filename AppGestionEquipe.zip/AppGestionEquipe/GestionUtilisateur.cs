﻿using AppGestionEquipe;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using BCrypt.Net;

namespace GestionnaireEvolutionEquipe
{
    public class GestionUtilisateur
    {
        private ConnexionBdd connexion;

        public GestionUtilisateur(ConnexionBdd connexion)
        {
            this.connexion = connexion;
        }

        public bool Creer(string pseudo, string email, string motDePasse, bool estGestionnaire = false)
        {
            // Vérifier si l'utilisateur existe déjà
            string query = "SELECT COUNT(*) FROM Utilisateur WHERE pseudo = '" + pseudo + "' OR email = '" + email + "'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count > 0)
            {
                Console.WriteLine("Un utilisateur avec ce pseudo ou cet email existe déjà.");
                return false;
            }

            string motDePasseHash = BCrypt.Net.BCrypt.HashPassword(motDePasse);

            // Insérer un nouvel utilisateur dans la base de données
            query = "INSERT INTO Utilisateur (pseudo, email, motDePasse, estGestionnaire) " +
                    "VALUES ('" + pseudo + "','" + email + "', '" + motDePasseHash + "'," + Convert.ToInt32(estGestionnaire) + ")";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Utilisateur créé avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la création de l'utilisateur.");
                return false;
            }
        }

        public bool Modifier(string pseudo, string nouveauPseudo, string nouvelEmail, string nouveauMotDePasse)
        {
            // Vérifier si le nouvel email est déjà utilisé par un autre utilisateur
            string query = "SELECT COUNT(*) FROM Utilisateur WHERE pseudo != '" + pseudo + "' AND email = '" + nouvelEmail + "'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count > 0)
            {
                Console.WriteLine("Un utilisateur avec cet email existe déjà.");
                return false;
            }

            // Hasher le nouveau mot de passe avec bcrypt
            string motDePasseHash = BCrypt.Net.BCrypt.HashPassword(nouveauMotDePasse);

            // Mettre à jour les informations de l'utilisateur dans la base de données
            query = "UPDATE Utilisateur SET pseudo = '" + nouveauPseudo + "', email = '" + nouvelEmail + "', motDePasse = '" + motDePasseHash + "' WHERE pseudo = '" + pseudo + "'";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Utilisateur modifié avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la modification de l'utilisateur.");
                return false;
            }
        }
        public bool Supprimer(string pseudo)
        {
            // Assurez-vous d'avoir votre logique de connexion à la base de données ici

            string deleteDemandesQuery = "DELETE FROM Demande_Adhesion WHERE idUtilisateur = (SELECT Id FROM Utilisateur WHERE Pseudo = '" + pseudo + "');";

            string deleteDemanderQuery = "DELETE FROM Demander WHERE idDemande_Adhesion IN (SELECT id FROM Demande_Adhesion WHERE idUtilisateur = (SELECT Id FROM Utilisateur WHERE Pseudo = '" + pseudo + "'));";

            string deleteUserQuery = "DELETE FROM Utilisateur WHERE Pseudo = '" + pseudo + "';";

            // Exécuter les requêtes de suppression
            bool demandeSupprimee = connexion.ExecuterNonRequete(deleteDemandesQuery) > 0;
            bool demanderSupprimee = connexion.ExecuterNonRequete(deleteDemanderQuery) > 0;
            bool utilisateurSupprime = connexion.ExecuterNonRequete(deleteUserQuery) > 0;

            // Vérifier si toutes les suppressions ont réussi
            if (demandeSupprimee && demanderSupprimee && utilisateurSupprime)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<DataRow> GetAll()
        {
            string query = "SELECT * FROM utilisateur";
            DataTable dataTable = connexion.ExecuterRequete(query);

            List<DataRow> utilisateurs = new List<DataRow>();

            foreach (DataRow row in dataTable.Rows)
            {
                utilisateurs.Add(row);
            }

            return utilisateurs;
        }

        public string GetRole(string pseudo, int idEquipe)
        {
            string query = "SELECT " +
                           "    CASE " +
                           "        WHEN utilisateur.estGestionnaire = 1 THEN 'Gestionnaire' " +
                           "        WHEN administrer.estHabiliteAdmin = 1 THEN 'Administrateur' " +
                           "        WHEN contenir.idRole IS NOT NULL THEN CAST(contenir.idRole AS VARCHAR) " +
                           "    END AS role " +
                           "FROM utilisateur " +
                           "LEFT JOIN contenir ON utilisateur.id = contenir.idUtilisateur " +
                           "LEFT JOIN administrer ON utilisateur.id = administrer.idUtilisateur AND contenir.idEquipe = administrer.idEquipe " +
                           "WHERE utilisateur.pseudo = " + pseudo + " AND contenir.idEquipe = " + idEquipe;

            DataTable result = connexion.ExecuterRequete(query);

            return result.Rows[0]["role"].ToString();

        }
    }
}
