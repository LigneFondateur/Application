﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGestionEquipe
{
    public class ConnexionBdd
    {
        private string connectionString;

        public ConnexionBdd()
        {
            // Chaine de connexion pré-renseignée
            connectionString = "Data Source=LAPTOP-UFPG8VKI\\SQLEXPRESS01;Initial Catalog=AppGestionEquipe;User ID=Test;Password=Test;Encrypt=False";
        }

        // Méthode pour exécuter une requête SELECT et retourner un DataTable
        // Type de requête pris en compte : SELECT
        public DataTable ExecuterRequete(string requete)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(requete, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataTable);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erreur lors de l'exécution de la requête : " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            return dataTable;
        }

        // Méthode pour exécuter une requête qui modifie les données dans la base de données
        // Type de requête pris en compte : INSERT, UPDATE, DELETE
        public int ExecuterNonRequete(string requete)
        {
            int lignesAffectees = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(requete, connection))
                    {
                        lignesAffectees = command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erreur lors de l'exécution de la requête non réceptive : " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            return lignesAffectees;
        }

        // Méthode pour exécuter une requête qui retourne une seule valeur (ex : COUNT, SUM)
        // Type de requête pris en compte : SELECT avec une fonction scalaire (ex : COUNT(), SUM())
        public object ExecuterScalaire(string requete)
        {
            object resultat = null;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(requete, connection))
                    {
                        resultat = command.ExecuteScalar();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erreur lors de l'exécution de la requête scalaire : " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            return resultat;
        }

        // Méthode pour exécuter une requête qui retourne un ensemble de lignes en lecture seule
        // Type de requête pris en compte : SELECT
        public SqlDataReader ExecuterLecteur(string requete)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataReader lecteur = null;
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(requete, connection);
                lecteur = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur lors de l'exécution du lecteur : " + ex.Message);
            }
            finally
            {
                if (lecteur != null && !lecteur.IsClosed)
                {
                    lecteur.Close();
                }
                connection.Close();
            }
            return lecteur;
        }
    }
}
