﻿using AppGestionEquipe;
using System;
using System.Collections.Generic;
using System.Data;

namespace GestionnaireEvolutionEquipe
{
    public class GestionEquipe
    {
        private ConnexionBdd connexion;

        public GestionEquipe(ConnexionBdd connexion)
        {
            this.connexion = connexion;
        }

        public bool Creer(string nom, int placesTotales)
        {
            // Vérifier si l'équipe existe déjà
            string query = $"SELECT COUNT(*) FROM Equipe WHERE nom = '{nom}'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count > 0)
            {
                Console.WriteLine("Une équipe avec ce nom existe déjà.");
                return false;
            }

            // Insérer une nouvelle équipe dans la base de données
            query = $"INSERT INTO Equipe (nom, placesTotales) VALUES ('{nom}', {placesTotales})";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Équipe créée avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la création de l'équipe.");
                return false;
            }
        }

        public bool Modifier(string ancienNom, string nouveauNom, int nouvellesPlacesTotales)
        {
            // Vérifier si l'équipe existe
            string queryEquipe = $"SELECT COUNT(*) FROM Equipe WHERE nom = '{ancienNom}'";
            int countEquipe = Convert.ToInt32(connexion.ExecuterScalaire(queryEquipe));
            if (countEquipe == 0)
            {
                Console.WriteLine("L'équipe spécifiée n'existe pas.");
                return false;
            }

            // Mettre à jour les informations de l'équipe dans la base de données
            string query = $"UPDATE Equipe SET nom = '{nouveauNom}', placesTotales = {nouvellesPlacesTotales} WHERE nom = '{ancienNom}'";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Équipe modifiée avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la modification de l'équipe.");
                return false;
            }
        }


        public bool Supprimer(string nom)
        {
            // Vérifier si l'équipe existe
            string query = $"SELECT COUNT(*) FROM Equipe WHERE nom = '{nom}'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count == 0)
            {
                Console.WriteLine("L'équipe spécifiée n'existe pas.");
                return false;
            }

            // Supprimer l'équipe de la base de données
            query = $"DELETE FROM Equipe WHERE nom = '{nom}'";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Équipe supprimée avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la suppression de l'équipe.");
                return false;
            }
        }
        public List<DataRow> GetAll()
        {
            string query = "SELECT * FROM Equipe";
            DataTable dataTable = connexion.ExecuterRequete(query);

            List<DataRow> equipes = new List<DataRow>();

            foreach (DataRow row in dataTable.Rows)
            {
                equipes.Add(row);
            }

            return equipes;
        }

        public DataTable GetUtilisateurs(string nomEquipe)
        {
            // Vérifier si l'équipe existe
            string queryEquipe = "SELECT COUNT(*) FROM Equipe WHERE nom = '" + nomEquipe + "'";
            int countEquipe = Convert.ToInt32(connexion.ExecuterScalaire(queryEquipe));
            if (countEquipe == 0)
            {
                Console.WriteLine("L'équipe spécifiée n'existe pas.");
                return null;
            }

            // Récupérer les utilisateurs associés à l'équipe
            string query = "SELECT u.* " +
                           "FROM Utilisateur u " +
                           "JOIN MembreEquipe me ON u.id = me.idUtilisateur " +
                           "JOIN Equipe e ON me.idEquipe = e.id " +
                           "WHERE e.nom = '" + nomEquipe + "'";

            DataTable result = connexion.ExecuterRequete(query);

            return result;
        }

    }
}
