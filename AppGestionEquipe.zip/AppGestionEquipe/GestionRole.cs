﻿using AppGestionEquipe;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGestionEquipe
{
    public class GestionRole
    {

        private ConnexionBdd connexion;

        public GestionRole(ConnexionBdd connexion)
        {
            this.connexion = connexion;
        }

        public bool Creer(string nom, string description)
        {
            // Vérifier si le rôle existe déjà
            string query = $"SELECT COUNT(*) FROM Role WHERE nom = '{nom}'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count > 0)
            {
                Console.WriteLine("Un rôle avec ce nom existe déjà.");
                return false;
            }

            // Insérer un nouveau rôle dans la base de données
            query = $"INSERT INTO Role (nom, description) VALUES ('{nom}', '{description}')";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Rôle créé avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la création du rôle.");
                return false;
            }
        }

        public bool Modifier(string nom, string nouveauNom, string nouvelleDescription)
        {
            // Vérifier si le rôle existe
            string query = $"SELECT COUNT(*) FROM Role WHERE nom = '{nom}'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count == 0)
            {
                Console.WriteLine("Le rôle spécifié n'existe pas.");
                return false;
            }

            // Mettre à jour le nom et la description du rôle dans la base de données
            query = $"UPDATE Role SET nom = '{nouveauNom}', description = '{nouvelleDescription}' WHERE nom = '{nom}'";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Rôle modifié avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la modification du rôle.");
                return false;
            }
        }



        public bool Supprimer(string nom)
        {
            // Vérifier si le rôle existe
            string query = $"SELECT COUNT(*) FROM Role WHERE nom = '{nom}'";
            int count = Convert.ToInt32(connexion.ExecuterScalaire(query));
            if (count == 0)
            {
                Console.WriteLine("Le rôle spécifié n'existe pas.");
                return false;
            }

            // Supprimer le rôle de la base de données
            query = $"DELETE FROM Role WHERE nom = '{nom}'";
            int lignesAffectees = connexion.ExecuterNonRequete(query);
            if (lignesAffectees > 0)
            {
                Console.WriteLine("Rôle supprimé avec succès.");
                return true;
            }
            else
            {
                Console.WriteLine("Échec de la suppression du rôle.");
                return false;
            }
        }

        public List<DataRow> GetAll()
        {
            string query = "SELECT * FROM Role";
            DataTable dataTable = connexion.ExecuterRequete(query);

            List<DataRow> roles = new List<DataRow>();

            foreach (DataRow row in dataTable.Rows)
            {
                roles.Add(row);
            }

            return roles;
        }

    }
}