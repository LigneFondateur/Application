﻿using GestionnaireEvolutionEquipe;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppGestionEquipe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void RemplirListeEquipes()
        {
            // Créer une instance de connexion à la base de données
            ConnexionBdd connexion = new ConnexionBdd();

            // Créer une instance de la classe GestionEquipe en lui passant la connexion à la base de données
            GestionEquipe gestionEquipe = new GestionEquipe(connexion);

            // Récupérer toutes les équipes depuis la base de données
            List<DataRow> equipes = gestionEquipe.GetAll();

            // Effacer les éléments précédemment ajoutés à lstEquipes
            lstEquipes.Items.Clear();

            // Ajouter le nom de chaque équipe à lstEquipes
            foreach (DataRow equipe in equipes)
            {
                lstEquipes.Items.Add(equipe["nom"].ToString());
            }
        }

        private void RemplirListeRoles()
        {
            // Créer une instance de connexion à la base de données
            ConnexionBdd connexion = new ConnexionBdd();

            // Créer une instance de la classe GestionEquipe en lui passant la connexion à la base de données
            GestionRole gestionRole = new GestionRole(connexion);

            // Récupérer toutes les équipes depuis la base de données
            List<DataRow> roles = gestionRole.GetAll();

            // Effacer les éléments précédemment ajoutés à lstEquipes
            lstRoles.Items.Clear();

            // Ajouter le nom de chaque équipe à lstEquipes
            foreach (DataRow role in roles)
            {
                lstRoles.Items.Add(role["nom"].ToString());
            }
        }
        private void RemplirListeUtilisateurs()
        {
            // Créer une instance de connexion à la base de données
            ConnexionBdd connexion = new ConnexionBdd();

            // Créer une instance de la classe GestionEquipe en lui passant la connexion à la base de données
            GestionUtilisateur gestionUtilisateur = new GestionUtilisateur(connexion);

            // Récupérer toutes les équipes depuis la base de données
            List<DataRow> utilisateurs = gestionUtilisateur.GetAll();

            // Effacer les éléments précédemment ajoutés à lstEquipes
            lstUtilisateurs.Items.Clear();

            // Ajouter le nom de chaque équipe à lstEquipes
            foreach (DataRow utilisateur in utilisateurs)
            {
                lstUtilisateurs.Items.Add(utilisateur["pseudo"].ToString());
            }
        }

        private void AfficherNombreDemandes()
        {
            // Créer une instance de connexion à la base de données
            ConnexionBdd connexion = new ConnexionBdd();

            GestionAdhesion gestionAdhesion = new GestionAdhesion(connexion);


            // Obtenez le nombre de demandes en appelant la méthode GetCount()
            int countDemandes = gestionAdhesion.GetCount();

            // Mettez à jour le texte de l'étiquette lblDemandes avec le nombre de demandes
            lblDemandes.Text = "Nombre de demandes : " + countDemandes.ToString();
            
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            AfficherNombreDemandes();
            RemplirListeEquipes();
            RemplirListeRoles();
            RemplirListeUtilisateurs();

        }

        private void BtnSupprimerEquipe_Click(object sender, EventArgs e)
        {
            // Vérifier si une équipe est sélectionnée dans la liste lstEquipes
            if (lstEquipes.SelectedIndex != -1)
            {
                // Obtenir le nom de l'équipe sélectionnée
                string nomEquipe = lstEquipes.SelectedItem.ToString();

                // Créer une instance de connexion à la base de données
                ConnexionBdd connexion = new ConnexionBdd();

                // Créer une instance de la classe GestionEquipe en lui passant la connexion à la base de données
                GestionEquipe gestionEquipe = new GestionEquipe(connexion);

                try
                {
                    // Supprimer l'équipe sélectionnée en utilisant la méthode Supprimer
                    bool suppressionReussie = gestionEquipe.Supprimer(nomEquipe);

                    // Vérifier si la suppression a réussi
                    if (suppressionReussie)
                    {
                        // Mettre à jour la liste lstEquipes après la suppression
                        lstEquipes.Items.Remove(lstEquipes.SelectedItem);
                        MessageBox.Show("Équipe supprimée avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de la suppression de l'équipe.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de la suppression de l'équipe : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une équipe à supprimer.");
            }
        }

        private void BtnModifierEquipe_Click(object sender, EventArgs e)
        {
            string InputBox(string prompt, string title, string defaultValue = "")
            {
                // Créer une nouvelle instance de Form
                Form promptForm = new Form();
                promptForm.Width = 500;
                promptForm.Height = 150;
                promptForm.Text = title;

                // Créer les contrôles pour le formulaire
                Label lblPrompt = new Label() { Left = 50, Top = 20, Width = 400, Text = prompt };
                TextBox txtInput = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 350, Width = 75, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Annuler", Left = 250, Width = 75, Top = 80, DialogResult = DialogResult.Cancel };

                // Ajouter les contrôles au formulaire
                promptForm.Controls.Add(lblPrompt);
                promptForm.Controls.Add(txtInput);
                promptForm.Controls.Add(btnOk);
                promptForm.Controls.Add(btnCancel);

                // Afficher le formulaire
                DialogResult result = promptForm.ShowDialog();

                // Vérifier si l'utilisateur a appuyé sur le bouton "Annuler"
                if (result == DialogResult.Cancel)
                {
                    // Ne rien faire si l'utilisateur a annulé
                    return null;
                }

                // Renvoyer la valeur saisie par l'utilisateur
                return txtInput.Text;
            }

            // Vérifier si une équipe est sélectionnée dans la liste lstEquipes
            if (lstEquipes.SelectedIndex != -1)
            {
                // Obtenir le nom de l'équipe sélectionnée
                string nomEquipe = lstEquipes.SelectedItem.ToString();

                // Créer une instance de la classe GestionEquipe en lui passant la connexion à la base de données
                ConnexionBdd connexion = new ConnexionBdd();
                GestionEquipe gestionEquipe = new GestionEquipe(connexion);

                try
                {
                    // Demander à l'utilisateur de saisir les nouvelles informations sur l'équipe
                    string nouveauNom = InputBox("Entrez le nouveau nom de l'équipe :", "Modification de l'équipe", "");
                    int nouvellesPlacesLibres = Convert.ToInt32(InputBox("Entrez le nouveau nombre de places libres :", "Modification de l'équipe", ""));

                    // Modifier l'équipe sélectionnée en utilisant la méthode Modifier
                    bool modificationReussie = gestionEquipe.Modifier(nomEquipe, nouveauNom, nouvellesPlacesLibres);

                    // Vérifier si la modification a réussi
                    if (modificationReussie)
                    {
                        // Mettre à jour la liste lstEquipes après la modification
                        // Remarque : la mise à jour de la liste dépend de l'implémentation de la méthode Modifier dans la classe GestionEquipe
                        MessageBox.Show("Équipe modifiée avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de la modification de l'équipe.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de la modification de l'équipe : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une équipe à modifier.");
            }
        }

        private void BtnAjouterEquipe_Click(object sender, EventArgs e)
        {

            string InputBox(string prompt, string title, string defaultValue = "")
            {
                // Créer une nouvelle instance de Form
                Form promptForm = new Form();
                promptForm.Width = 500;
                promptForm.Height = 150;
                promptForm.Text = title;

                // Créer les contrôles pour le formulaire
                Label lblPrompt = new Label() { Left = 50, Top = 20, Width = 400, Text = prompt };
                TextBox txtInput = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 350, Width = 75, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Annuler", Left = 250, Width = 75, Top = 80, DialogResult = DialogResult.Cancel };

                // Ajouter les contrôles au formulaire
                promptForm.Controls.Add(lblPrompt);
                promptForm.Controls.Add(txtInput);
                promptForm.Controls.Add(btnOk);
                promptForm.Controls.Add(btnCancel);

                // Afficher le formulaire
                DialogResult result = promptForm.ShowDialog();

                // Renvoyer la valeur saisie par l'utilisateur ou une chaîne vide si l'utilisateur a annulé
                return result == DialogResult.OK ? txtInput.Text : "";
            }


            // Afficher une boîte de dialogue pour saisir le nom de l'équipe
            string nouveauNomEquipe = InputBox("Entrez le nom de l'équipe :", "Ajouter une nouvelle équipe", "");

            // Vérifier si l'utilisateur a saisi un nom d'équipe
            if (!string.IsNullOrEmpty(nouveauNomEquipe))
            {
                // Afficher une boîte de dialogue pour saisir la description de l'équipe
                int nouvellesPlacesLibres = int.TryParse(InputBox("Entrez le nombre de places libres de l'équipe :", "Ajouter une nouvelle équipe", ""), out int result) ? result : 0;

                // Vérifier si l'utilisateur a saisi une description d'équipe
                if (nouvellesPlacesLibres != 0)
                {
                    // Créer une instance de la classe GestionEquipe en lui passant la connexion à la base de données
                    ConnexionBdd connexion = new ConnexionBdd();
                    GestionEquipe gestionEquipe = new GestionEquipe(connexion);

                    try
                    {
                        // Appelez la méthode Creer pour ajouter une nouvelle équipe
                        bool creationReussie = gestionEquipe.Creer(nouveauNomEquipe, nouvellesPlacesLibres);

                        // Vérifiez si la création a réussi
                        if (creationReussie)
                        {
                            // Rafraîchissez votre liste d'équipes si nécessaire
                            lstEquipes.Items.Clear();
                            lstEquipes.Items.AddRange(gestionEquipe.GetAll().ToArray());

                            MessageBox.Show("Équipe ajoutée avec succès.");
                        }
                        else
                        {
                            MessageBox.Show("Échec de l'ajout de l'équipe.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Gérez les erreurs éventuelles
                        MessageBox.Show("Erreur lors de l'ajout de l'équipe : " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez entrer un nombre de places pour l'équipe.");
                }
            }
            else
            {
                MessageBox.Show("Veuillez entrer un nom pour l'équipe.");
            }
        }


        private void BtnSupprimerRole_Click(object sender, EventArgs e)
        {
            // Vérifier si un rôle est sélectionné dans la liste lstRoles
            if (lstRoles.SelectedIndex != -1)
            {
                // Obtenir le nom du rôle sélectionné
                string nomRole = lstRoles.SelectedItem.ToString();

                // Créer une instance de connexion à la base de données
                ConnexionBdd connexion = new ConnexionBdd();

                // Créer une instance de la classe GestionRole en lui passant la connexion à la base de données
                GestionRole gestionRole = new GestionRole(connexion);

                try
                {
                    // Supprimer le rôle sélectionné en utilisant la méthode Supprimer
                    bool suppressionReussie = gestionRole.Supprimer(nomRole);

                    // Vérifier si la suppression a réussi
                    if (suppressionReussie)
                    {
                        // Mettre à jour la liste lstRoles après la suppression
                        lstRoles.Items.Remove(lstRoles.SelectedItem);
                        MessageBox.Show("Rôle supprimé avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de la suppression du rôle.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de la suppression du rôle : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un rôle à supprimer.");
            }
        }

        private void BtnModifierRole_Click(object sender, EventArgs e)
        {
            string InputBox(string prompt, string title, string defaultValue = "")
            {
                // Créer une nouvelle instance de Form
                Form promptForm = new Form();
                promptForm.Width = 500;
                promptForm.Height = 150;
                promptForm.Text = title;

                // Créer les contrôles pour le formulaire
                Label lblPrompt = new Label() { Left = 50, Top = 20, Width = 400, Text = prompt };
                TextBox txtInput = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 350, Width = 75, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Annuler", Left = 250, Width = 75, Top = 80, DialogResult = DialogResult.Cancel };

                // Ajouter les contrôles au formulaire
                promptForm.Controls.Add(lblPrompt);
                promptForm.Controls.Add(txtInput);
                promptForm.Controls.Add(btnOk);
                promptForm.Controls.Add(btnCancel);

                // Afficher le formulaire
                DialogResult result = promptForm.ShowDialog();

                // Vérifier si l'utilisateur a appuyé sur le bouton "Annuler"
                if (result == DialogResult.Cancel)
                {
                    // Ne rien faire si l'utilisateur a annulé
                    return null;
                }

                // Renvoyer la valeur saisie par l'utilisateur
                return txtInput.Text;
            }

            // Vérifier si un rôle est sélectionné dans la liste lstRoles
            if (lstRoles.SelectedIndex != -1)
            {
                // Obtenir le nom du rôle sélectionné
                string nomRole = lstRoles.SelectedItem.ToString();

                // Créer une instance de la classe GestionRole en lui passant la connexion à la base de données
                ConnexionBdd connexion = new ConnexionBdd();
                GestionRole gestionRole = new GestionRole(connexion);

                try
                {
                    // Demander à l'utilisateur de saisir les nouvelles informations sur le rôle
                    string nouveauNom = InputBox("Entrez le nouveau nom du rôle :", "Modification du rôle", "");
                    string nouvelleDescription = InputBox("Entrez la nouvelle description du rôle :", "Modification du rôle", "");

                    // Modifier le rôle sélectionné en utilisant la méthode Modifier
                    bool modificationReussie = gestionRole.Modifier(nomRole, nouveauNom, nouvelleDescription);

                    // Vérifier si la modification a réussi
                    if (modificationReussie)
                    {
                        // Mettre à jour la liste lstRoles après la modification
                        // Remarque : la mise à jour de la liste dépend de l'implémentation de la méthode Modifier dans la classe GestionRole
                        MessageBox.Show("Rôle modifié avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de la modification du rôle.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de la modification du rôle : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un rôle à modifier.");
            }
        }

        private void BtnAjouterRole_Click(object sender, EventArgs e)
        {

            string InputBox(string prompt, string title, string defaultValue = "")
            {
                // Créer une nouvelle instance de Form
                Form promptForm = new Form();
                promptForm.Width = 500;
                promptForm.Height = 150;
                promptForm.Text = title;

                // Créer les contrôles pour le formulaire
                Label lblPrompt = new Label() { Left = 50, Top = 20, Width = 400, Text = prompt };
                TextBox txtInput = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 350, Width = 75, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Annuler", Left = 250, Width = 75, Top = 80, DialogResult = DialogResult.Cancel };

                // Ajouter les contrôles au formulaire
                promptForm.Controls.Add(lblPrompt);
                promptForm.Controls.Add(txtInput);
                promptForm.Controls.Add(btnOk);
                promptForm.Controls.Add(btnCancel);

                // Afficher le formulaire
                DialogResult result = promptForm.ShowDialog();

                // Renvoyer la valeur saisie par l'utilisateur ou une chaîne vide si l'utilisateur a annulé
                return result == DialogResult.OK ? txtInput.Text : "";
            }


            // Afficher une boîte de dialogue pour saisir le nom du rôle
            string nomRole = InputBox("Entrez le nom du rôle :", "Ajouter un nouveau rôle", "");

            // Vérifier si l'utilisateur a saisi un nom de rôle
            if (!string.IsNullOrEmpty(nomRole))
            {
                // Afficher une boîte de dialogue pour saisir la description du rôle
                string descriptionRole = InputBox("Entrez la description du rôle :", "Ajouter un nouveau rôle", "");

                // Vérifier si l'utilisateur a saisi une description de rôle
                if (!string.IsNullOrEmpty(descriptionRole))
                {
                    // Créer une instance de la classe GestionRole en lui passant la connexion à la base de données
                    ConnexionBdd connexion = new ConnexionBdd();
                    GestionRole gestionRole = new GestionRole(connexion);

                    try
                    {
                        // Appelez la méthode Créer pour ajouter un nouveau rôle
                        bool creationReussie = gestionRole.Creer(nomRole, descriptionRole);

                        // Vérifiez si la création a réussi
                        if (creationReussie)
                        {
                            // Rafraîchissez votre liste de rôles si nécessaire
                            // lstRoles.Items.Clear();
                            // Chargez à nouveau les rôles dans la liste lstRoles
                            // Exemple : lstRoles.Items.AddRange(gestionRole.ObtenirTous().ToArray());

                            MessageBox.Show("Rôle ajouté avec succès.");
                        }
                        else
                        {
                            MessageBox.Show("Échec de l'ajout du rôle.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Gérez les erreurs éventuelles
                        MessageBox.Show("Erreur lors de l'ajout du rôle : " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez entrer une description pour le rôle.");
                }
            }
            else
            {
                MessageBox.Show("Veuillez entrer un nom pour le rôle.");
            }
        }




        private void BtnSupprimerUtilisateur_Click(object sender, EventArgs e)
        {
            if (lstUtilisateurs.SelectedIndex != -1)
            {
                string nomUtilisateur = lstUtilisateurs.SelectedItem.ToString();

                ConnexionBdd connexion = new ConnexionBdd();
                GestionUtilisateur gestionUtilisateur = new GestionUtilisateur(connexion);


                try
                {
                    bool suppressionReussie = gestionUtilisateur.Supprimer(nomUtilisateur);

                    // Vérifier si la suppression a réussi
                    if (suppressionReussie)
                    {
                        lstUtilisateurs.Items.Remove(lstUtilisateurs.SelectedItem);
                        MessageBox.Show("Utilisateur supprimé avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de la suppression de l'utilisateur.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de la suppression de l'utilisateur : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un utilisateur à supprimer.");
            }
        }

        private void BtnModifierUtilisateur_Click(object sender, EventArgs e)
        {
            string InputBox(string prompt, string title, string defaultValue = "")
            {
                // Créer une nouvelle instance de Form
                Form promptForm = new Form();
                promptForm.Width = 500;
                promptForm.Height = 150;
                promptForm.Text = title;

                // Créer les contrôles pour le formulaire
                Label lblPrompt = new Label() { Left = 50, Top = 20, Width = 400, Text = prompt };
                TextBox txtInput = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 350, Width = 75, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Annuler", Left = 250, Width = 75, Top = 80, DialogResult = DialogResult.Cancel };

                // Ajouter les contrôles au formulaire
                promptForm.Controls.Add(lblPrompt);
                promptForm.Controls.Add(txtInput);
                promptForm.Controls.Add(btnOk);
                promptForm.Controls.Add(btnCancel);

                // Afficher le formulaire
                DialogResult result = promptForm.ShowDialog();

                // Vérifier si l'utilisateur a appuyé sur le bouton "Annuler"
                if (result == DialogResult.Cancel)
                {
                    // Ne rien faire si l'utilisateur a annulé
                    return null;
                }

                // Renvoyer la valeur saisie par l'utilisateur
                return txtInput.Text;
            }

            // Vérifier si un utilisateur est sélectionné dans la liste lstUtilisateurs
            if (lstUtilisateurs.SelectedIndex != -1)
            {
                // Obtenir le nom de l'utilisateur sélectionné
                string nomUtilisateur = lstUtilisateurs.SelectedItem.ToString();

                // Créer une instance de la classe GestionUtilisateur en lui passant la connexion à la base de données
                ConnexionBdd connexion = new ConnexionBdd();
                GestionUtilisateur gestionUtilisateur = new GestionUtilisateur(connexion);

                try
                {
                    // Demander à l'utilisateur de saisir les nouvelles informations sur l'utilisateur
                    string nouveauPseudo = InputBox("Entrez le nouveau pseudo de l'utilisateur :", "Modification de l'utilisateur", "");
                    string nouvelEmail = InputBox("Entrez le nouvel email de l'utilisateur :", "Modification de l'utilisateur", "");
                    string nouveauMotDePasse = InputBox("Entrez le nouveau mot de passe de l'utilisateur :", "Modification de l'utilisateur", "");

                    // Modifier l'utilisateur sélectionné en utilisant la méthode Modifier
                    bool modificationReussie = gestionUtilisateur.Modifier(nomUtilisateur, nouveauPseudo, nouvelEmail, nouveauMotDePasse);

                    // Vérifier si la modification a réussi
                    if (modificationReussie)
                    {
                        // Mettre à jour la liste lstUtilisateurs après la modification
                        // Remarque : la mise à jour de la liste dépend de l'implémentation de la méthode Modifier dans la classe GestionUtilisateur
                        MessageBox.Show("Utilisateur modifié avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de la modification de l'utilisateur.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de la modification de l'utilisateur : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un utilisateur à modifier.");
            }
        }

        private void BtnAjouterUtilisateur_Click(object sender, EventArgs e)
        {
            string InputBox(string prompt, string title, string defaultValue = "")
            {
                // Créer une nouvelle instance de Form
                Form promptForm = new Form();
                promptForm.Width = 500;
                promptForm.Height = 150;
                promptForm.Text = title;

                // Créer les contrôles pour le formulaire
                Label lblPrompt = new Label() { Left = 50, Top = 20, Width = 400, Text = prompt };
                TextBox txtInput = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 350, Width = 75, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Annuler", Left = 250, Width = 75, Top = 80, DialogResult = DialogResult.Cancel };

                // Ajouter les contrôles au formulaire
                promptForm.Controls.Add(lblPrompt);
                promptForm.Controls.Add(txtInput);
                promptForm.Controls.Add(btnOk);
                promptForm.Controls.Add(btnCancel);

                // Afficher le formulaire
                DialogResult result = promptForm.ShowDialog();

                // Vérifier si l'utilisateur a appuyé sur le bouton "Annuler"
                if (result == DialogResult.Cancel)
                {
                    // Ne rien faire si l'utilisateur a annulé
                    return null;
                }

                // Renvoyer la valeur saisie par l'utilisateur
                return txtInput.Text;
            }

            // Demander à l'utilisateur de saisir les informations sur le nouvel utilisateur
            string pseudo = InputBox("Entrez le pseudo de l'utilisateur :", "Ajouter un nouvel utilisateur", "");
            string email = InputBox("Entrez l'email de l'utilisateur :", "Ajouter un nouvel utilisateur", "");
            string motDePasse = InputBox("Entrez le mot de passe de l'utilisateur :", "Ajouter un nouvel utilisateur", "");

            // Vérifier si l'utilisateur a saisi toutes les informations nécessaires
            if (!string.IsNullOrEmpty(pseudo) && !string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(motDePasse))
            {
                // Créer une instance de la classe GestionUtilisateur en lui passant la connexion à la base de données
                ConnexionBdd connexion = new ConnexionBdd();
                GestionUtilisateur gestionUtilisateur = new GestionUtilisateur(connexion);

                try
                {
                    // Ajouter le nouvel utilisateur en utilisant la méthode Creer
                    bool creationReussie = gestionUtilisateur.Creer(pseudo, email, motDePasse);

                    // Vérifier si la création a réussi
                    if (creationReussie)
                    {
                        // Mettre à jour la liste lstUtilisateurs après l'ajout
                        // Remarque : la mise à jour de la liste dépend de l'implémentation de la méthode Creer dans la classe GestionUtilisateur
                        MessageBox.Show("Utilisateur ajouté avec succès.");
                    }
                    else
                    {
                        MessageBox.Show("Échec de l'ajout de l'utilisateur.");
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs éventuelles
                    MessageBox.Show("Erreur lors de l'ajout de l'utilisateur : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez saisir toutes les informations nécessaires.");
            }
        }

    }
}

